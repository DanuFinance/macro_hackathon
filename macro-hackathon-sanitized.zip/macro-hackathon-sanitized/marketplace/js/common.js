/* Written for Danu, 2022 */

/* Functionality common to all templates */


"use strict";


window.addEventListener("load", () => {
	document.body.classList.add("loaded");
});

