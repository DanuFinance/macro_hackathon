/* Written for Danu, 2022 */

/* Functionality common to all marketplace tabs */


const menu_items = document.querySelectorAll('aside ul[role="doc-toc"] button');

const tabs = document.getElementsByClassName('tabs');


/* Convience function for showing popups */
function popup(params = {
	title: "Lorem ipsum dolor sit amet",
	closeable: true,
	message: ""
}) {
	document.body.insertAdjacentHTML(`beforeend`, `
		<div class="popup-wrapper">
			<div class="popup-contents signup-metamask">
				<div class="title_bar">
					<span>${params['title']}</span>
					<button class="close"` + (!params['closeable'] ? ' disabled' : '') + `><svg viewBox="0 0 320 512"><use href="assets/icons.svg#xmark"/></svg>Close</button>
				</div>
				<div class="message">
					${params['message']}
				</div>
			</div>
		</div>
	`);

	if (params['closeable']) {
		document.onkeydown = (event) => {
			if (event.key === "Escape")
				document.querySelector('.popup-wrapper').remove();
		};

		document.querySelector('.popup-wrapper button.close').onclick = (event) => {
			document.querySelector('.popup-wrapper').remove();
		}
	}
}


/* Implements tab switching (i.e. "Discover", "Swap", "Provide liquidity") functionality */
function switch_tab(event) {
	[...menu_items].forEach(button => {
		button.setAttribute('aria-current', button.id === event.target.id ? true : false);
	});

	[...tabs].forEach((tab) => {
		tab.setAttribute('aria-current', tab.id === event.target.id ? true : false);
	});
}

