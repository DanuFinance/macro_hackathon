# Written for Danu, 2022

import numpy
import sdepy


@sdepy.integrate(q=0, sources = ["dt", "dn"])
def model(t: np.array, T: np.array, xi: float, f: float, sigma: float):
    """Stochastic drift-diffusion equation inspired by ..."""

    return {
            "dt": xi * f * T,
            "dn": sigma * T
    }


def appraise() -> None:
    pass

